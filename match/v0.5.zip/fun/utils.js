export const MORRISONS = "groceries.morrisons";
export const ASDA = "groceries.asda";

export const MORRISONS_SEARCH = "https://groceries.morrisons.com/search?entry=";
export const ASDA_SEARCH = "https://groceries.asda.com/search/";

export const ALL_STORES = ["MORRISONS","ASDA"];
export const STORES_URLS = {
	"MORRISONS":"https://" + MORRISONS,
	"ASDA":"https://" + ASDA
};

export const RESULTS_TO_LOAD = 10;

const weightReplaces = [["ml",""],["l",""],["g",""],["kg",""],["per pack","pk"],[" ",""]];

export function didSearchFail(doc) {
	let store = storeFromUrl(doc.location.href);

	if (store === "MORRISONS") {
		return doc.getElementsByClassName("nf-resourceNotFound").length > 0;
	} else if (store === "ASDA") {
		return doc.getElementsByClassName("search-page-content__no-result").length > 0;
	};
}

export function storeFromUrl(url, upper=true) {
	let store;
	
	if (url.includes(utils.MORRISONS)) {
		store = "MORRISONS"
	} else if (url.includes(utils.ASDA)) {
		store = "ASDA"
	};

	if (!upper) { store = store.toLowerCase() };

	return store;
};

export function waitForElement(selector, orFail=false, doc=null) {
	return new Promise(resolve => {
		let found = document.querySelector(selector);
		if (found || (orFail == true && didSearchFail(doc))) { resolve(found) };

		const observer = new MutationObserver(changes => {
			let found = document.querySelector(selector);
			if (found || (orFail == true && didSearchFail(doc))) {observer.disconnect(); resolve(found)};
		});

		observer.observe(document.body, {childList:true, subtree:true});
	});
};

export function waitForEntries(cls) {
	return new Promise(resolve => {
		let found = document.getElementsByClassName(cls);
		if (found.length > 0) { resolve(found) };

		const observer = new MutationObserver(changes => {
			let found = document.getElementsByClassName(cls);
			if (found.length > 0) {observer.disconnect(); resolve(found)};
		});

		observer.observe(document.body, {childList:true, subtree:true});
	});
};

export function waitFor(i, e, orFail=false, doc=null) {
	return new Promise(resolve => {
		let found = i.getElementsByClassName(e);
		if (found.length > 0 || (orFail == true && didSearchFail(doc))) { resolve(found) };

		const observer = new MutationObserver(changes => {
			let found = i.getElementsByClassName(e);
			if (found.length > 0 || (orFail == true && didSearchFail(doc))) {observer.disconnect(); resolve(found)};
		});

		observer.observe(i, {childList:true, subtree:true});
	});
};

export function waitForContent(i, e) {
	return new Promise(resolve => {
		let found = i.getElementsByClassName(e);
		if (found.length > 0 && found[0].innerText !== "") { resolve(found) };

		let checkInterval;

		setInterval(function() {
			found = i.getElementsByClassName(e);
			if (found.length > 0 && found[0].innerText !== "") {
				clearInterval(checkInterval);
				resolve(found);
			};
		}, 250);
	});
};

export function delay(ms) {
	let start = Date.now();	

	return new Promise(resolve => {
		while (Date.now() < start + ms) {};
		resolve(Date.now());
	});
};

export function matchWeights(w1,w2) {
	w1 = w1.toLowerCase();
	w2 = w2.toLowerCase();

	for (let i of weightReplaces) {
		w1 = w1.replaceAll(i[0],i[1]);
		w2 = w2.replaceAll(i[0],i[1]);
	};

	console.log(w1,w2);

	return w1 === w2;
};

export function prettyUrl(before) {
	let pretty;

	console.log(before);
	if (before.includes(MORRISONS)) {
		let id = before.match(/groceries.morrisons.com\/products\/.+?-(-{0}\d+)$/);
		if (!id) { return before };

		pretty = "https://" + MORRISONS + ".com/products/" + id[1];

	} else if (before.includes(ASDA)) {
		let id = before.match(/groceries.asda.com\/product\/.+?\/.+?\/(\d+)/);
		if (!id) { return before };

		pretty = "https://" + ASDA + ".com/product/" + id[1];

	};

	console.log(pretty);
	return pretty;
};

export function formatPrice(priceText) {
	if (priceText.includes("£") && !priceText.includes(".")) {
		priceText = priceText + ".00";
	};

	return priceText;
};

export function priceInt(priceText) {
	//return in PENCE.

	if (priceText.includes("p")) {
		priceText = priceText.replace("p","");
		return Number(priceText);
	} else {
		if (priceText.includes(".")) {
			return Number(priceText.replace("£","").replace(".",""));
		} else {
			return Number(priceText.replace("£",""))*100;
		};
	};
};

export function format_search(term) {
	console.log(term,typeof(term));

	term = term.toLowerCase();

	for (let s of ALL_STORES) {
		term = term.replaceAll(s.toLowerCase());
	};
	
	let str = "";

	for (let word of term.split(" ")) {
		str = str  + word + "%20";
	};

	return str;
};

export function getTodayStr() {
	const d = new Date();
	return `${d.getDate()}-${d.getMonth()+1}-${d.getFullYear()}`;
};

export async function cacheGet(key) {
	const storage = await browser.storage.local.get();
	const dateKey = getTodayStr();

	if (!storage.cache || !storage.cache[dateKey]) {
		return new Promise(resolve => {resolve(null)});
	};

	return new Promise(resolve => {resolve(storage.cache[dateKey][key])});
};

export async function cacheSet(key, value) {
	const storage = await browser.storage.local.get();
	const dateKey = getTodayStr();

	if (!storage.cache) { storage["cache"] = {} };
	
	if (!storage.cache[dateKey]) { 
		storage.cache = {}; //removing past caches. only will happen once a day.
		storage.cache[dateKey] = {};
	};

	storage.cache[dateKey][key] = value;

	await browser.storage.local.set(storage);

	return new Promise(resolve => {resolve(storage.cache)});
}

export function biggerImg(url) {
	if (url.includes("asda")) {
		if (!url.includes("?")) { url += "?" };

		if (url.includes("wid")) {
			url = url.replace(/wid=\d+/,"wid=640");

		} else {
			if (url.slice(-1) !== "&" && url.slice(-1) !== "?") { url += "&" };
			url += "wid=640";
		};

		if (url.includes("hei")) {
			url = url.replace(/hei=\d+/,"hei=640");

		} else {
			if (url.slice(-1) !== "&" && url.slice(-1) !== "?") { url += "&" };
			url += "hei=640";
		};

	} else if (url.includes("morrisons")) {
		url = url.replace(/_\d+x\d+./,"_640x640.")
	};

	return url;
};