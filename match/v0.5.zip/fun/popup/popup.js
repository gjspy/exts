import { format_search, MORRISONS, ASDA, MORRISONS_SEARCH, ASDA_SEARCH, prettyUrl } from "../utils.js"

const SEARCH_MATCH = "//(.+).com/"

/*TODO: asda bundles, offers
show if the price is an offer!!! on comparison page
use strict

new nav system: ext/compare?morrisons=id, then we load asda page n bkg if not cached, all handled by compare not popup
******when url changed prompt rematch********
nicer list totals
compare in plugin popup
logo - favicon too
updating
donyt make it close when search result bad
similar results
*/

let utils;

console.log("hello there");

async function compare(storage, matches) {
	storage.job.info.search = "";
	storage.job.info.matches = matches;

	const uncached = [];
	console.log(JSON.stringify(matches));

	for (let i of matches.others) {
		let cached = await utils.cacheGet(utils.prettyUrl(i));

		if (cached) {
			storage.job[cached.store.toLowerCase()] = [cached];
		} else {
			uncached.push(i);
		};
	};
	
	if (uncached.length === 0) {
		document.getElementById("header").innerText = "";
		document.getElementById("main-btns").style.display = "none";
		document.getElementById("debug-cont").style.display = "none";
		document.getElementById("go-back").hidden = false;
		return;
	};
	await browser.storage.local.set(storage);

	for (let i of uncached) {
		browser.tabs.create({url:i});
	};

	browser.tabs.create({url:"/pages/compare/index.html"})
};

async function search(url, search) {
	//get results via search then present them on match menu

	console.log(url);

	//MUST EDIT FOR NEW STORES
	if (url !== MORRISONS) {
		browser.tabs.create({url:MORRISONS_SEARCH+search});
	};

	if (url !== ASDA) {
		browser.tabs.create({url:ASDA_SEARCH+search});
	};

	browser.tabs.create({url:"/pages/match/index.html"});
}

async function assertProductPage() {
	let tabs = await browser.tabs.query({currentWindow:true,active:true});

	let raw_url = tabs[0].url;
	let url = raw_url.match(SEARCH_MATCH);
	console.log(url);

	if ((url === null) || (url[1] !== MORRISONS && url[1] !== ASDA)) {
		document.getElementById("error").textContent = "I don't recognise this URL.";
		return [false, tabs, raw_url, url];
	};

	url = url[1];

	if (!tabs[0].url.match("product")) { // if is a product page
		document.getElementById("error").innerHTML = "This doesn't seem like a product page!<br>You must be on an individual product's page to use this.";
		return [false, tabs, raw_url, url];
	};

	console.log(true, tabs, raw_url, url);
	return [true, tabs, raw_url, url];
};

async function mainCompare(event, forceMatch=false) {
	let [isProduct, tabs, raw_url, url] = await assertProductPage();

	if (!isProduct) { return };

	document.getElementById("error").textContent = "Starting job!";

	//get info shown currently on the screen
	let n,w,p,i,store;

	//MUST EDIT FOR NEW STORES
	if (url === MORRISONS) {
		n = "n = document.getElementsByClassName(\"bop-title\")[0].children[0].firstChild.nodeValue;";
		w = "w = document.getElementsByClassName(\"bop-catchWeight\")[0].innerText;";
		p = "p = document.getElementsByClassName(\"bop-price__current \")[0].innerText;";
		i = "i = document.getElementsByClassName(\"bop-gallery__image\")[0].currentSrc;";
		store = "MORRISONS";

	} else if (url === ASDA) {
		n = "n = document.getElementsByClassName(\"pdp-main-details__title\")[0].innerText;";
		w = "w = document.getElementsByClassName(\"pdp-main-details__weight\")[0].innerText;";
		p = "p = document.getElementsByClassName(\"co-product__price pdp-main-details__price\")[0].innerText.replace(\"now\\n\",\"\");";
		i = "i = document.getElementsByClassName(\"asda-image picture\")[0].firstChild.srcset;";// /asda-img asda-image asda-image-zoom__zoomed-image[0].currentSrc; 
		store = "ASDA";

	};

	let script = n + w + p + i + "[n,w,p,i];";

	console.log(script);

	let info = await browser.tabs.executeScript(null,{code:script});
	console.log(JSON.stringify(info));

	let thisItemName = info[0][0];
	let thisItemWeight = info[0][1];
	let thisItemPrice = info[0][2];
	let thisItemImageUrl = info[0][3];

	let searchTerm = format_search(thisItemName); //+ " " + thisItemWeight

	let storage = await browser.storage.local.get() ?? {};

	storage["job"] = {
		"info":{
			"name":thisItemName,
			"weight":thisItemWeight,
			"imageUrl":utils.biggerImg(thisItemImageUrl),
			"price":thisItemPrice,
			"search":searchTerm,
			"url":utils.prettyUrl(raw_url),
			"store":store,
			"bulk":[raw_url],
			"tabCameFrom":tabs[0]
		}
	};

	// decide whether to use thsi info to make matches or compare

	if (storage.matches && forceMatch === false) {
		let pretty = prettyUrl(raw_url);
		let matches = storage.matches[pretty];

		if (matches && matches.others.length === utils.ALL_STORES.length-1) {
			compare();

		} else {
			await browser.storage.local.set(storage);
			search(url, searchTerm);
		};

	} else {
		await browser.storage.local.set(storage);
		search(url, searchTerm);
	};

	const toCache = {};
	Object.assign(toCache,storage.job.info);

	delete toCache["search"];
	delete toCache["bulk"];
	delete toCache["tabCameFrom"];
	//delete toCache["store"];

	await utils.cacheSet(utils.prettyUrl(toCache.url), toCache);
};

async function clearMatches() {
	let s = await browser.storage.local.get();

	s.matches = {};

	await browser.storage.local.set(s);
};

async function dump() {
	const blob = new Blob([JSON.stringify(await browser.storage.local.get())], {type:"application/json"});
	browser.tabs.create({url:URL.createObjectURL(blob)});
};

async function init() {
	utils = await import(browser.runtime.getURL("../utils.js"));
	console.log(utils.ASDA_SEARCH);
};

function openDebug() {
	const div = document.getElementById("debug-cont");
	let display;

	if (div.style.display === "none") { display = "flex"; } else { display = "none"; };
	div.style.display = display;
};

async function clearCache() {
	console.log("clearing cache");
	const storage = await browser.storage.local.get();
	storage.cache = {};
	await browser.storage.local.set(storage);
};

function goBack() {
	document.getElementById("header").innerText = "Price Match";
	document.getElementById("main-btns").style.display = "flex";
	document.getElementById("debug-cont").style.display = "none";
	document.getElementById("lists").innerHTML = "";
	document.getElementById("go-back").hidden = true;
};

async function changeList(list, box, clickedText, thisUrl) {
	if (clickedText) { box.checked = !box.checked };

	const storage = await browser.storage.local.get();
	const thisList = storage.lists[list]
	
	if (box.checked === true) {
		thisList.push(thisUrl);
	} else {
		thisList.splice(thisList.indexOf(thisUrl), 1);
	};

	await browser.storage.local.set(storage);
};

async function createList(name, item) {
	const storage = await browser.storage.local.get();
	if (!storage.lists) {storage.lists = {}};

	storage.lists[name] = [item];
	await browser.storage.local.set(storage);
};

async function showListsForAdd() {
	let [isProduct, tabs, raw_url, url] = await assertProductPage();

	if (!isProduct) { return };

	const storage = await browser.storage.local.get();

	document.getElementById("header").innerText = "Add To List";
	document.getElementById("main-btns").style.display = "none";
	document.getElementById("debug-cont").style.display = "none";
	document.getElementById("go-back").hidden = false;

	function createLi(name, thisUrl, checked) {
		const li = document.createElement("li");
		li.style = "list-style-type: none;"

		const box = document.createElement("input");
		box.type = "checkbox";
		box.addEventListener("click", function() {changeList(url, box, false, thisUrl)});
		box.checked = checked;

		const txt = document.createElement("a");
		txt.textContent = name;
		txt.style = "cursor: pointer;"
		txt.addEventListener("click", function() {changeList(name, box, true, thisUrl)});

		li.append(box, txt);
		return li;
	};

	const thisUrl = utils.prettyUrl(raw_url);
	
	if (storage.lists) {
		for (let i of Object.keys(storage.lists)) {
			console.log("i",i)
			let checked = false;

			if (storage.lists[i].includes(thisUrl)) { checked = true };

			if (storage.matches[thisUrl]) {
				for (let m of storage.matches[thisUrl].others) {
					if (storage.lists[i].includes(m)) { checked = true; break };
				};
			};

			
			document.getElementById("lists").append(createLi(i, thisUrl, checked));
		};
	};

	const li = document.createElement("li");
	li.style = "list-style-type: none;"

	const txt = document.createElement("a");
	txt.textContent = " + ";

	const input = document.createElement("input");
	input.type = "text";
	input.style = "width: 70px";
	input.placeholder = "New List";

	input.addEventListener("keydown", function(ev) {
		if (ev.key === "Enter") { 
			createList(input.value, thisUrl);
			document.getElementById("lists").append(createLi(input.value, thisUrl, true));

			goBack();
			//showListsForAdd();
		};
	});

	li.append(txt, input);
	document.getElementById("lists").append(li);
};

async function showListsForView() {
	const storage = await browser.storage.local.get();

	document.getElementById("header").innerText = "View List";
	document.getElementById("main-btns").style.display = "none";
	document.getElementById("debug-cont").style.display = "none";
	document.getElementById("go-back").hidden = false;

	for (let i of Object.keys(storage.lists)) {
		const li = document.createElement("li");

		const txt = document.createElement("a");
		txt.textContent = i;
		txt.style = "color: blue; text-decoration: underline; cursor: pointer;"
		txt.addEventListener("click", function() { browser.tabs.create({url: "/pages/listview/index.html?list=" + i})});

		li.append(txt);
		document.getElementById("lists").append(li);
	};
};

init().then(() => {
	document.getElementById("compare").addEventListener("click", mainCompare);
	document.getElementById("vfy-match").addEventListener("click", (event) => {mainCompare(event, true)});
	document.getElementById("clr-matches").addEventListener("click", clearMatches);
	document.getElementById("dmp").addEventListener("click", dump);
	document.getElementById("debug").addEventListener("click", openDebug);
	document.getElementById("clr-cache").addEventListener("click", clearCache);
	document.getElementById("add-list").addEventListener("click", showListsForAdd);
	document.getElementById("view-list").addEventListener("click", showListsForView);
	document.getElementById("go-back").addEventListener("click", goBack);
});