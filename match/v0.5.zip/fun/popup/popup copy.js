const MORRISONS = "groceries.morrisons"
const ASDA = "groceries.asda"

const MORRISONS_SEARCH = "https://groceries.morrisons.com/search?entry="
const ASDA_SEARCH = "https://groceries.asda.com/search/"

const SEARCH_MATCH = "//(.+).com/"

//morissons pissy - made me do a captcha
/*TODO: asda bundles, offers
save matches in storage then allow export?
show if the price is an offer!!! on comparison page
*/
console.log("hello there");

function format_search(term) {
	str = "";

	for (let word of term.split(" ")) {
		str = str  + word + "%20";
	};

	return str;
};

function onStorageSet(result, url, thisItemName) {
	let search = format_search(thisItemName);
	console.log(url);

	if (url !== MORRISONS) {
		browser.tabs.create({url:MORRISONS_SEARCH+search});
	};

	if (url !== ASDA) {
		browser.tabs.create({url:ASDA_SEARCH+search});
	};

	browser.tabs.create({url:"/pages/compare/index.html"});

	/*if (url !== MORRISONS) {
		var newMBtn = document.createElement("button")
		newMBtn.textContent = "Click to load MORRISONS"
		newMBtn.onclick = function(e) {newMBtn.remove(); window.open(MORRISONS_SEARCH + search)}

		document.body.appendChild(newMBtn)
		document.body.appendChild(document.createElement("br"))
	};

	if (url !== ASDA) {
		var newABtn = document.createElement("button")
		newABtn.textContent = "Click to load ASDA"
		newABtn.onclick = function(e) {newABtn.remove(); window.open(ASDA_SEARCH + search)}



		document.body.appendChild(newABtn)
		document.body.appendChild(document.createElement("br"))
	};*/

	//here, other pages have been loaded in the background.
	//wont be in bkg for dad: HOW TO MAKE POPUP STAY ?
};

function onStorageGet(result, url, thisItemName, thisItemWeight, thisItemPrice, thisItemImageUrl) {
	result = result ?? {};

	console.log("onStorageGet");

	result["job"] = {
		"info":{"name":thisItemName, "weight":thisItemWeight, "imageUrl":thisItemImageUrl,"price":thisItemPrice,"search":format_search(thisItemName),"url":url},
		//url:{price}
	};

	console.log(JSON.stringify(result));

	browser.storage.local.set(result).then(function(r) {onStorageSet(r,url,thisItemName)}, console.error);		
};

function onScriptExecute(result, url) {
	console.log("script executed");

	info = result[0];

	var thisItemName = info[0];
	var thisItemWeight = info[1];
	var thisItemPrice = info[2];
	var thisItemImageUrl = info[3]

	console.log(info)

	browser.storage.local.get().then(function(r) {onStorageGet(r,url,thisItemName,thisItemWeight,thisItemPrice, thisItemImageUrl)}, console.error);
};

function onQueriedTabs(tabs) {
	let url = tabs[0].url.match(SEARCH_MATCH);
	console.log(url);

	if ((url === null) | (url[1] !== MORRISONS & url[1] !== ASDA)) {
		document.getElementById("error").textContent = "I don't recognise this as an ASDA or MORRISONS url.";
		return;
	};

	url = url[1];

	if (!tabs[0].url.match("product")) { // if is a product page
		document.getElementById("error").innerHTML = "This doesn't seem like a product page!<br>You must be on an individual product's page to use this.";
		return;
	};

	document.getElementById("error").textContent = "Starting job!";

	let n = "";
	let w = "";
	let p = "";
	let i = "";

	if (url === MORRISONS) {
		n = "n = document.getElementsByClassName(\"bop-title\")[0].children[0].firstChild.nodeValue;";
		w = "w = document.getElementsByClassName(\"bop-catchWeight\")[0].innerText;";
		p = "p = document.getElementsByClassName(\"bop-price__current \")[0].innerText;";
		i = "i = document.getElementsByClassName(\"bop-gallery__image\")[0].currentSrc;";

	} else if (url === ASDA) {
		n = "n = document.getElementsByClassName(\"pdp-main-details__title\")[0].innerText;";
		w = "w = document.getElementsByClassName(\"pdp-main-details__weight\")[0].innerText;";
		p = "p = document.getElementsByClassName(\"co-product__price pdp-main-details__price\")[0].innerText.replace(\"now\\n\",\"\");";
		i = "i = document.getElementsByClassName(\"asda-img asda-image asda-image-zoom__zoomed-image\")[0].currentSrc;";

	};

	let script = n + w + p + i + "[n,w,p,i];";

	console.log(script);
	
	browser.tabs.executeScript(null,{code:script}).then(function(r) {onScriptExecute(r, url)}, console.error);
};

document.getElementById("compare").addEventListener("click", (event) => {
	console.log("happened");
	
	//get this tab url
	//window.open(MORRISONS_SEARCH)
	browser.tabs.query({currentWindow: true, active: true}).then(onQueriedTabs, console.error);
});