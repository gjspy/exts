let storesDone = [];
let oneTimeTasksDone = false;
let resultObj;
let utils;
let interval;


async function display(job, store) {
	let c = document.getElementById("template").cloneNode(true);
	c.id = "";
	c.getElementsByClassName("prod-header")[0].textContent = store;
	c.getElementsByClassName("prod-img")[0].src = job.imageUrl;
	c.getElementsByClassName("prod-price")[0].textContent = utils.formatPrice(job.price);
	c.getElementsByClassName("prod-weight")[0].textContent = job.weight;

	let name = c.getElementsByClassName("prod-name")[0];
	name.textContent = job.name;
	name.href = job.url;

	c.style = "display: inline-grid; justify-items: center;";
	
	document.getElementsByClassName("container")[0].append(c);
};

async function hasJob(storage) {
	console.log("waiting");

	if ((storage.job.asda && !storesDone.includes("ASDA")) || (storage.job.morrisons && !storesDone.includes("MORRISONS"))) { //MORE STORES: ADD POSSIBLE HERE
		if (storage.job.asda) {
			storesDone.push("ASDA");

			display(storage.job.asda[0], "ASDA");
		};
		
		if (storage.job.morrisons) {
			storesDone.push("MORRISONS");

			display(storage.job.morrisons[0], "MORRISONS");
		};

		console.log(storesDone);

		if (storesDone.length == utils.ALL_STORES.length) {
			clearInterval(interval);
			document.getElementById("loading").remove();
		};	
	};
};

async function oneTimeTasks(storage) {
	//show item we're comparing from (store 1)

	display(storage.job.info, storage.job.info.store)

	/*resultObj = document.getElementsByClassName("result")[0];

	let c = resultObj.cloneNode(true);
	c.getElementsByClassName("prod-header")[0].textContent = storage.job.info.store;
	c.getElementsByClassName("prod-img")[0].src = storage.job.info.imageUrl;
	c.getElementsByClassName("prod-price")[0].textContent = storage.job.info.price;
	c.id = "";

	let name = c.getElementsByClassName("prod-name")[0];
	name.textContent = storage.job.info.name;
	name.href = storage.job.info.url;

	c.style = "display: inline-grid; justify-items: center;";
	
	document.getElementsByClassName("container")[0].append(c);*/
};

async function main() {
	const storage = await browser.storage.local.get();

	if (storage.job) {
		if (oneTimeTasksDone === false) {
			storesDone.push(storage.job.info.store);
			oneTimeTasks(storage); 
			oneTimeTasksDone = true;
		};

		hasJob(storage);
	};
};

async function init() {
	utils = await import(browser.runtime.getURL("../utils.js"));
	console.log(utils.ASDA_SEARCH);
};

init().then(() => {
	interval = setInterval(main,500);
});