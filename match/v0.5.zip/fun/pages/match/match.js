//import { prettyUrl, utils.matchWeights, utils.ALL_STORES } from "../../utils";

const youSure = "I'm sure";

let storesDone = [];
let oneTimeTasksDone = false;
let resultObj;
let utils;
let interval;
let manualChooseInterval;

async function onCheck(box, info1, info2) {
	console.log("clicked", JSON.stringify(info1), JSON.stringify(info2));
	let display;
	if (box.checked === true) { display = "none" } else { display = "block"};

	for (let i of document.getElementById(info2.storeDiv+"-ul").children) {
		if (i.id !== info2.id) { i.style.display = display};
	};

	if (box.checked === true) {
		document.getElementById(info2.storeDiv).children[1].hidden = true;

		let confirm = document.getElementById("match-confirm");
		confirm.style="display: block;";

		let btn = confirm.getElementsByTagName("button")[0];
		btn.textContent = "Confirm Match";
		btn.onclick = function() {onConfirm(btn, info1, info2)};

		let msg = confirm.getElementsByTagName("a")[0];
		msg.style = "";
		msg.innerHTML = "";

		document.body.append(confirm);

	} else {
		document.getElementById(info2.storeDiv).children[1].hidden = false;
		document.getElementById("match-confirm").style = "display: none;";
	};
};

async function actualConfirm(info1, info2) {
	storage = await browser.storage.local.get();

	if (!storage.matches) { storage["matches"] = {} };

	let pretty1 = utils.prettyUrl(info1.url);
	let pretty2 = utils.prettyUrl(info2.url);

	//console.log(pretty1);
	//console.log(pretty2);

	storage.matches[pretty1] = {"others":[pretty2],"name":info1.name + " " + info1.weight};
	storage.matches[pretty2] = {"others":[pretty1],"name":info2.name + " " + info2.weight};

	await browser.storage.local.set(storage);

	document.getElementById("confirm-message").textContent = "Match stored!";
	await utils.delay(1000);

	//browser.tabs.update(info1.tabCameFrom.id,{active:true});
	/*console.log(JSON.stringify(info1));
	let tabOpened = await browser.tabs.getCurrent();
	console.log(tabOpened.url, tabOpened.openerTabId)
	browser.tabs.update(tabOpened.openerTabId, {active:true, highlighted:true});*/

	let cameFrom = info1.tabCameFrom || info2.tabCameFrom;
	console.log("camefrom",cameFrom);
	browser.tabs.update(cameFrom.id, {active:true, highlighted:true});
	window.close();
};

async function onConfirm(btn, info1, info2) {
	console.log("confirm", JSON.stringify(info1));

	if (btn.textContent === youSure) {
		actualConfirm(info1, info2);
		return;

	} else if (!utils.matchWeights(info1.weight, info2.weight)) {
		let msg = document.getElementById("confirm-message");

		msg.style = "color: rgb(255,0,0)";
		msg.innerHTML = "The sizes of these items seem different.<br>Are you sure they match?";

		btn.textContent = youSure;
		return;

	} else {
		actualConfirm(info1, info2);
		return;
	};
};

async function waitUntilManualChoice(store, storeDiv) {
	const storage = await browser.storage.local.get();
	const chosen = storage.job["chosen_"+store];

	console.log(JSON.stringify(storage));

	if (chosen) {
		clearInterval(manualChooseInterval);
		console.log(storeDiv);
		const ul = document.getElementById(storeDiv+"-ul");

		chosen["storeDiv"] = storeDiv
		chosen["id"] = storeDiv + "-" + String(ul.children.length);

		//const matchTab = await browser.tabs.query({"title":"Match"}).slice(-1)[0];
		//await browser.tabs.highlight({"tabs":[matchTab.id]});

		const li = createEntry(storage.job.info, chosen, true);
		ul.append(li);

		onCheck({"checked":true}, storage.job.info, chosen);

		window.focus(); //borwser.tabs.highlight(browser.tabs.getthis())
	};
};

async function clickSearchLink(goto, name, id) {
	const storage = await browser.storage.local.get();

	storage.job["missing_" + name.toLowerCase()] = {"info":goto};

	await browser.storage.local.set(storage);
	browser.tabs.create({url:goto});

	manualChooseInterval = setInterval(function() { waitUntilManualChoice(name.toLowerCase(), id) }, 1000);
};

function createEntry(info, i, manual=false) {
	let c = resultObj.cloneNode(true);
	let bold = i.weight;
	let star = i.name;

	if (utils.matchWeights(info.weight, i.weight)) { bold = "<b>" + i.weight + "</b>"};
	if (manual === true) { star = "* " + i.name + " *" };

	c.getElementsByClassName("prod-name")[0].innerText = star;
	c.getElementsByClassName("prod-weight")[0].innerHTML = bold;
	c.getElementsByClassName("prod-price")[0].innerText = utils.formatPrice(i.price);
	c.getElementsByClassName("prod-img")[0].src = i.imageUrl;

	let link = c.getElementsByClassName("prod-link")[0];
	link.innerText = "Store Page";
	link.href = i.url;

	c.hidden = false;
	c.id = i["id"];

	let checkBox = c.getElementsByTagName("input")[0];
	checkBox.onclick = function() {onCheck(checkBox, info, i)}

	if (manual === true) {
		checkBox.checked = true;
	};

	return c;
}

async function display(id, name, job, info, showSearchLink=false, cache=true) {
	let store = document.getElementById("store-template").cloneNode(true);
	store.id = id;

	const h2 = store.children[0].children[0];
	h2.textContent = name;
	h2.style = "display: inline; margin-left: 40px;";

	const l = document.createElement("ul");
	l.style = "display: inline-block; margin-top: 0px; list-style-type:none";
	l.id = id + "-ul";

	if (showSearchLink === true) {
		const sl = store.children[1];
		sl.addEventListener("click", function() {clickSearchLink(utils[name + "_SEARCH"] + info.search, name, id)})
		sl.hidden = false;
	};

	if (job["failed"] === true) {
		const text = document.createElement("a");
		text.textContent = "No results found.";
		l.append(text);
		store.append(l);
		document.body.append(store);
		return;
	};

	let count = 0;

	for (let i of job) {
		if (cache === true) { await utils.cacheSet(utils.prettyUrl(i.url), i) };

		i["storeDiv"] = id;
		i["id"] = id + "-" + String(count);

		const li = createEntry(info, i);

		l.append(li);
		console.log(i);

		count += 1;		
	};

	store.append(l);
	document.body.append(store);
};

async function hasJob(storage) {
	if ((storage.job.asda && !storesDone.includes("ASDA")) || (storage.job.morrisons && !storesDone.includes("MORRISONS"))) { //MORE STORES: ADD POSSIBLE HERE
		if (storage.job.asda) {
			storesDone.push("ASDA");
			display("store-"+storesDone.length, "ASDA", storage.job.asda, storage.job.info, true);			
		};
		
		if (storage.job.morrisons) {
			storesDone.push("MORRISONS");
			display("store-"+storesDone.length, "MORRISONS", storage.job.morrisons, storage.job.info, true);
		};

		console.log(storesDone);

		if (storesDone.length == utils.ALL_STORES.length) {
			for (let i of document.getElementsByClassName("result-box")) {
				i.disabled = false;
			};

			clearInterval(interval);
			console.log("infooooo",JSON.stringify(storage.job.info));
			document.getElementById("loading").remove();
		};	
	};
};

async function oneTimeTasks(storage) {
	//show item we're comparing from (store 1)
	storage.job.info["storeDiv"] = "store-1";

	let store1 = document.getElementById("store-1");
	store1.children[0].children[0].textContent = storage.job.info.store;

	store1.append(createEntry(storage.job.info, storage.job.info))
};

async function main() {
	const storage = await browser.storage.local.get();
	console.log("wating");

	if (storage.job) {
		if (oneTimeTasksDone === false) {
			storesDone.push(storage.job.info.store);
			oneTimeTasks(storage); 
			oneTimeTasksDone = true;
		};

		hasJob(storage);
	};
};

async function init() {
	utils = await import(browser.runtime.getURL("../utils.js"));
	resultObj = document.getElementsByClassName("row-x")[0];
};

init().then(() => {
	interval = setInterval(main,500);
});
//main();

/*old: <div class="result" hidden>
	<img src="" class="prod-img">
	<label class="prod-name" style="display:inline-block">[NAME]</label><br>
	<label class="prod-weight" style="display:inline-block">[WEIGHT]</label><br>
	<label class="prod-price" style="display:inline-block">[PRICE]</label>
</div>
c.getElementsByClassName("prod-weight")[0].textContent = storage.job.info.weight;
c.getElementsByClassName("prod-price")[0].textContent = storage.job.info.price;*/

/*<label id="product-label">Product Name:</label>
	<input type="text" id="product-input"><button type="button" id="compare">Go</button><br>
	<hr id="line" hidden> */
