let storesDone = [];
let oneTimeTasksDone = false;
let resultObj;
let utils;
let interval;
let itemsLoading = 0;

function updateTots() {
	for (let i of document.getElementsByClassName("store-ul")) {
		let price = 0;

		for (let r of i.children) {
			let priceText = r.getElementsByClassName("grand-tot")[0].textContent || r.getElementsByClassName("prod-price")[0].textContent;
			price += utils.priceInt(priceText);
		};

		price = String(price/100);
		if (price.includes(".") && price.slice(price.indexOf(".")).length !== 3) { price += "0"	};
		i.parentElement.getElementsByClassName("ult-tot")[0].textContent = "£" + price;//"£" + price.slice(0,-2) + "." + price.slice(-2);
	};
};

function typing(ev, row) {
	let chpElem, chpPrice, expElem, expPrice;

	for (let i of document.getElementsByClassName("row-"+row)) {
		const thisPrice = utils.priceInt(i.getElementsByClassName("prod-price")[0].textContent) * ev.target.value;
		let priceStr = String(thisPrice/100);

		if (priceStr.includes(".") && priceStr.slice(priceStr.indexOf(".")).length !== 3) { priceStr += "0"	};

		i.getElementsByTagName("input")[0].value = ev.target.value;
		i.getElementsByClassName("grand-tot")[0].textContent = "£" + priceStr;//"£" + priceStr.slice(0,-2) + "." + priceStr.slice(-2);
		i.getElementsByClassName("saving")[0].textContent = "";

		if (chpPrice === thisPrice) {
			chpElem = undefined;
			chpPrice = undefined;
			expElem = undefined;
			expPrice = undefined;

		} else if (chpPrice === undefined || thisPrice < chpPrice) {
			expElem = chpElem;
			expPrice = chpPrice;

			chpElem = i;
			chpPrice = thisPrice;			
		} else {
			expElem = i;
			expPrice = thisPrice;
		};
	};

	console.log(chpPrice,chpElem,expPrice);
	if (chpPrice && chpElem && expPrice) {
		const diff = expPrice-chpPrice;
		let priceStr = String(diff/100);

		if (priceStr.includes(".") && priceStr.slice(priceStr.indexOf(".")).length !== 3) { priceStr += "0"	};
		chpElem.getElementsByClassName("saving")[0].textContent = "(-" + priceStr + ")"; //"(-" + priceStr.slice(0,-2) + "." + priceStr.slice(-2) + ")";
	};

	updateTots();
};

async function remove(row) {
	const name = document.title;

	let urls = [];

	console.log(document.getElementsByClassName("row-"+row));
	for (let i of Array.from(document.getElementsByClassName("row-"+row)).values()) {
		console.log(i);
		urls.push(i.getElementsByClassName("prod-link")[0].href);
		i.remove();
	};

	const storage = await browser.storage.local.get();
	console.log(urls);

	for (let u of urls) {
		if (storage.lists[name].includes(u)) {
			storage.lists[name].splice(storage.lists[name].indexOf(u),1);
		};
	};

	await browser.storage.local.set(storage);


}

function createTempEntry(url, row) {
	let c = resultObj.cloneNode(true);

	c.getElementsByClassName("prod-name")[0].innerText = "LOADING";
	c.getElementsByClassName("prod-weight")[0].innerText = "LOADING";
	c.getElementsByClassName("prod-link")[0].text = url;
	c.getElementsByClassName("prod-img")[0].src = "";
	c.hidden = false;
	c.setAttribute("class", "row-"+row);
	c.style = "width: 100%; display: inline-flex;"

	c.getElementsByTagName("input")[0].addEventListener("input", function(ev) { typing(ev, row)});
	c.getElementsByClassName("remove")[0].addEventListener("click", function() { remove(row) });

	return c;
}

function createStoreDiv(name) {
	const store = document.getElementById("store-template").cloneNode(true);
	store.id = name;

	const h2 = store.children[0].children[0];
	h2.textContent = name;
	h2.style = "display: inline; margin-left: 40px;";

	const l = document.createElement("ul");
	l.setAttribute("class","store-ul");
	l.style = "display: inline-flex; margin-top: 0px; list-style-type:none; width: fit-content; flex-direction: column;";
	l.id = name + "-ul";

	store.append(l);
	document.body.append(store);
	return store;
};

async function populateEntry(elem, url) {
	itemsLoading += 1

	let interval = setInterval(async function() {
		const cached = await utils.cacheGet(url);

		if (cached) {
			clearInterval(interval);
			itemsLoading -= 1
			console.log(cached);

			elem.getElementsByClassName("prod-name")[0].innerText = cached.name;
			elem.getElementsByClassName("prod-weight")[0].innerText = cached.weight;
			elem.getElementsByClassName("prod-price")[0].innerText = utils.formatPrice(cached.price);
			elem.getElementsByClassName("prod-img")[0].src = cached.imageUrl;

			let link = elem.getElementsByClassName("prod-link")[0];
			link.innerText = "Store Page";
			link.href = cached.url;
			
		};
	}, 500);
};

async function onceLoaded() {
	let tots = {};

	for (let i of Array(document.getElementById("ASDA-ul").children.length).keys()) {
		let cheapestElem, price;

		for (let r of document.getElementsByClassName("row-"+i)) {
			//let match = r.getElementsByClassName("prod-info")[0].innerText.match(/.+\n.+\n(.+)\n/)[1];
			let thisPrice = utils.priceInt(r.getElementsByClassName("prod-price")[0].innerText);

			if (!tots[r.parentElement.id]) { tots[r.parentElement.id] = 0 };
			tots[r.parentElement.id] += thisPrice;

			if (price === thisPrice) {
				cheapestElem = undefined;
				price = undefined;
			} else if (price === undefined || thisPrice < price) {
				cheapestElem = r;
				price = thisPrice;
			};
		};

		if (cheapestElem) { cheapestElem.style["font-weight"] = "bold" };
		//cheapestElem.innerHTML = "<b>" + cheapestElem.innerHTML + "</b>";
	};

	for (let i of document.getElementsByClassName("store-ul")) {
		let priceText = String(tots[i.id]);

		const t = document.createElement("a");
		t.style = "display: block; margin-left: 40px;";
		t.textContent = "£" + priceText.slice(0,-2) + "." + priceText.slice(-2);
		t.setAttribute("class","ult-tot")
	
		i.parentElement.append(t);
	};
};

async function displayList(listName) {
	const storage = await browser.storage.local.get();
	const list = storage.lists[listName];

	const stores = [];

	for (let i of Object.keys(utils.STORES_URLS)) {
		console.log(i);
		stores.push(createStoreDiv(i));
	};

	const toGather = [];
	let row = 0;

	let missing = [];

	for (let i of list) {
		let thisStore;
		let url;

		let id = i.match(/(\d+)/)[1];

		if (i.includes(utils.MORRISONS)) {
			thisStore = document.getElementById("MORRISONS-ul");
			url = "https://" + utils.MORRISONS + ".com/products/" + id;
		} else if (i.includes(utils.ASDA)) {
			thisStore = document.getElementById("ASDA-ul");
			url = "https://" + utils.ASDA + ".com/product/" + id;
		};

		let entry = createTempEntry(i,row);
		thisStore.append(entry);

		if (!await utils.cacheGet(i)) {
			toGather.push(i);
		};

		let matches = storage.matches[i];
		if (!matches) {
			missing.push(url);
			//browser.tabs.create({url:url});
		}; //TODO: WAIT UNTIL MATCH MADE?

		if (missing.length > 0) { break };

		entry.getElementsByClassName("prod-name")[0].textContent = matches.name;
		populateEntry(entry, i);
		matches = matches;

		for (let m of matches.others) {
			let store;

			if (m.includes(utils.MORRISONS)) {
				store = document.getElementById("MORRISONS-ul");
			} else if (m.includes(utils.ASDA)) {
				store = document.getElementById("ASDA-ul");
			};

			entry = createTempEntry(m, row);
			store.append(entry);

			if (storage.matches[m]) {
				entry.getElementsByClassName("prod-name")[0].innerText = storage.matches[m].name;
			};
			populateEntry(entry,m);

			if (!await utils.cacheGet(m)) {
				toGather.push(m);
			};
		};

		row += 1;
	};

	if (missing.length > 0) {
		window.alert("This list has unmatched items.\nOpening in new tabs now..");

		for (let i of missing) {
			browser.tabs.create({url:i});
		};

		return;
	};

	if (toGather.length > 0) {
		console.log(toGather);

		storage.job = {
			"info":{
				"bulk":toGather
			}
		};

		await browser.storage.local.set(storage);

		for (let i of toGather) {
			browser.tabs.create({url:i});
		};
	};

	let waiting = setInterval(async function() {
		console.log(itemsLoading);

		if (itemsLoading === 0) {
			clearInterval(waiting);
			await onceLoaded();
			console.log("finsihed everythng!");
		};
	}, 500);
};

async function deleteList() {
	const storage = await browser.storage.local.get();

	delete storage.lists[document.title];

	await browser.storage.local.set(storage);
	window.close();
};

function rename() {
	const box = document.createElement("input");
	box.style = "vertical-align: middle;margin-left: 10px;";

	box.addEventListener("keydown", async function(ev) {
		if (ev.key === "Enter") {
			const storage = await browser.storage.local.get();

			if (storage.lists[box.value] || box.value === "") {
				document.getElementById("header").textContent = "Bad Name!";
				return;
			};
			storage.lists[box.value] = storage.lists[document.title];
			delete storage.lists[document.title];

			await browser.storage.local.set(storage);

			window.location.assign("/pages/listview/index.html?list="+box.value);
		};
	});

	document.getElementById("header").insertAdjacentElement("beforeend",box);
};

async function init() {
	utils = await import(browser.runtime.getURL("../utils.js"));
	console.log(utils.ASDA_SEARCH);

	resultObj = document.getElementsByClassName("row-x")[0];
};

init().then(async function() {
	const params = new URLSearchParams(document.location.search);
	const name = params.get("list");

	document.title =  name;
	document.getElementById("header").textContent = name;

	await displayList(name);

	document.getElementById("del").addEventListener("click", deleteList);
	document.getElementById("rn").addEventListener("click", rename);
});

/*<div id="store-1" class="store" style="display: inline-block; vertical-align: top;">
		<u class="store-title">
		<h2 style="display: inline"></h2>
	</u>
	<br>
</div> */