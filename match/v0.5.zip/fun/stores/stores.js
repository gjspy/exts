//import { waitForElement, waitFor, waitForEntries, delay, ASDA_SEARCH, RESULTS_TO_LOAD, ASDA } from "../utils.js";

//import { MORRISONS } from "../utils";

//let waitForElement, waitFor, waitForEntries, delay, ASDA_SEARCH, RESULTS_TO_LOAD, ASDA

const ELEMENTS = {
	"ASDA":{
		"lsiName":"co-product__anchor",
		"lsiWeight":"co-product__volume co-item__volume",
		"lsiPrice":"co-product__price",
		"lsiImage":"asda-img asda-image thumbnail__image",
		"lsResult":" co-item co-item--rest-in-shelf ",
		"resCont":"search-page-content__products-tab-content",

		"prodName":"pdp-main-details__title",
		"prodWeight":"pdp-main-details__weight",
		"prodPrice":"co-product__price pdp-main-details__price",
		"prodImage":"asda-image picture",//"asda-image-zoom__zoomed-image-container asda-image-zoom__zoomed-image-container--hide",

		"topBar":"top-menu",
		"aStyle":"font-weight: bolder;",
		"colour":"#efffd6",
		"boxStyle":"float: right; height: 20px; width: 20px;",

		"banned":[

		]
	},
	"MORRISONS":{
		"lsiName":"fop-title",
		"lsiWeight":"fop-catch-weight",
		"lsiPrice":"fop-price",
		"lsiImage":"fop-img",
		"lsResult":"fops-item fops-item",
		"resCont":"fops fops-regular fops-shelf",

		"prodName":"bop-title",
		"prodWeight":"bop-catchWeight",
		"prodPrice":"bop-price__current",
		"prodImage":"bop-gallery__image",

		"topBar":"hd-header__content",
		"aStyle":"font-size: 30px;margin-top: 10px;position: absolute;",
		"colour":"#fff5c0",
		"boxStyle":"float: right; height: 20px; width: 20px;margin-bottom: -20px;margin-right: 1px;margin-top: 1px;z-index: 1;position: relative;",

		"banned":[
			"sidebar-element recommended-fops"
		]
	}
};

let utils;

async function getFromListItem(i, store) {
	let name, weight, price, image, url
	
	if (store === "ASDA") {
		let nameElem = i.getElementsByClassName(ELEMENTS[store].lsiName)[0];
		weight = i.getElementsByClassName(ELEMENTS[store].lsiWeight)[0].innerText;
		price = i.getElementsByClassName(ELEMENTS[store].lsiPrice)[0].childNodes[1].data;
		image = i.getElementsByClassName(ELEMENTS[store].lsiImage)[0].currentSrc;

		name = nameElem.innerText;
		url = nameElem.href;
	} else if (store === "MORRISONS") {
		let nameElem = i.getElementsByClassName(ELEMENTS[store].lsiName)[0];
		weight = i.getElementsByClassName(ELEMENTS[store].lsiWeight)[0].innerText;
		price = i.getElementsByClassName(ELEMENTS[store].lsiPrice)[0].innerText;
		image = i.getElementsByClassName(ELEMENTS[store].lsiImage)[0].currentSrc;

		name = nameElem.innerText;

		url = nameElem.parentElement.parentElement.parentElement.href;
	};

	console.log(name, weight, price, image);

	const info = {
		"name":name,
		"weight":weight,
		"price":price,
		"imageUrl":utils.biggerImg(image),
		"url":url,
		"store":store
	};

	await utils.cacheSet(utils.prettyUrl(info.url), info);

	return new Promise(resolve => {resolve(info)});
};

async function checkedBox(item, store) {
	const storage = await browser.storage.local.get();
	
	storage.job["chosen_" + store.toLowerCase()] = await getFromListItem(item, store);

	await browser.storage.local.set(storage);
	
	window.close();


	document.querySelector("html").innerHTML = "Couldn't close automatically<br>Please return to match window."
};

async function manualSearch(storage, store) {
	console.log("MANUAL SEARCH!")
	const topMenu = document.getElementsByClassName(ELEMENTS[store].topBar)[0];

	const a = document.createElement("a");
	a.innerHTML = "Matching: " + storage.job.info.search.replaceAll("%20"," ");
	a.style = ELEMENTS[store].aStyle;

	topMenu.insertAdjacentElement("afterbegin", a);

	let allResults = document.getElementsByClassName(ELEMENTS[store].lsResult);
	allResults = Array.from(allResults);

	console.log(allResults);

	const storageWeight = storage.job.info.weight;

	for (let i of allResults) {
		let thisWeight = i.getElementsByClassName(ELEMENTS[store].lsiWeight)[0].innerText;

		console.log(storageWeight, thisWeight, utils.matchWeights(storageWeight, thisWeight));

		if (utils.matchWeights(storageWeight, thisWeight)) {
			i.style.background = ELEMENTS[store].colour;
		};

		const c = document.createElement("input");
		c.type = "checkbox";
		c.style = ELEMENTS[store].boxStyle;
		c.addEventListener("click", function() { checkedBox(i, store) });

		if (store === "ASDA") {
			i.children[0].children[0].insertAdjacentElement("afterbegin", c);
		} else if (store === "MORRISONS") {
			if (i.children.length > 1) {
				i.children[1].insertAdjacentElement("afterbegin",c);
			} else {
				i.children[0].insertAdjacentElement("afterbegin", c);
			};
		};
	};
};

async function scrapingSearch(storage, store) {
	let allResults = document.getElementsByClassName(ELEMENTS[store].lsResult);
	allResults = Array.from(allResults);

	let sliced = allResults.slice(0, Math.min(allResults.length, utils.RESULTS_TO_LOAD));
	let usefulResults = [];

	for (let i of sliced) {
		console.log("waiting");
		await utils.waitFor(i,ELEMENTS[store].lsiImage)

		console.log("waited");

		usefulResults.push(await getFromListItem(i, store));
	};

	storage.job[store.toLowerCase()] = usefulResults;

	await browser.storage.local.set(storage);
	console.log(JSON.stringify(usefulResults));
	console.log(usefulResults);
	window.close();
}

async function fromSearch(store) {
	console.log("waitinf or container or fail",ELEMENTS[store].resCont);
	await utils.waitFor(document,ELEMENTS[store].resCont, true, document);
	console.log("got resultContainer")

	if (utils.didSearchFail(document) === true) {
		const storage = await browser.storage.local.get();
		storage.job[store.toLowerCase()] = {"failed": true};
		await browser.storage.local.set(storage);
		console.log("set failed");
		window.close();
		return;
	};

	console.log("didnt fail");
	
	for (let i of ELEMENTS[store].banned) {
		for (let e of document.getElementsByClassName(i)) {
			e.remove();
		};
	};

	await utils.waitForEntries(ELEMENTS[store].lsiImage);
	console.log("got entries", store);

	const storage = await browser.storage.local.get();

	const missing = storage.job["missing_"+store.toLowerCase()]
	
	if (!storage.job) {return};
	if (!missing && storage.job[store.toLowerCase()]) {return};

	if (!missing) {
		if (window.location.href !== utils[store+"_SEARCH"] + storage.job.info.search) { return };
	} else {
		if (!window.location.href.includes(utils[store+"_SEARCH"]) && !window.location.href.includes("browse")) { return };
	};

	if (missing) {
		setTimeout(manualSearch, 500, storage, store);
	} else {
		scrapingSearch(storage, store);
	};
};


async function fromProduct(store) {
	console.log("waiting 1", window.location.href);
	await utils.waitFor(document, ELEMENTS[store].prodName);
	console.log("waiting 2");
	await utils.waitFor(document,ELEMENTS[store].prodImage);
	console.log("waiting 3");
	await utils.waitForContent(document, ELEMENTS[store].prodName);
	console.log("waited all");

	for (let i of ELEMENTS[store].banned) {
		for (let e of document.getElementsByClassName(i)) {
			e.remove();
		};
	};

	const storage = await browser.storage.local.get();

	let bulk = false;

	if (!storage.job) {return};
	console.log("have job");
	if (storage.job[store.toLowerCase()]) {return};
	console.log("not yet done this store");
	if (storage.job.info.bulk.length === 1) {
		console.log("have matches")
		if (storage.job.info.matches && !storage.job.info.matches.others.includes(utils.prettyUrl(window.location.href))) {return};
	} else if (storage.job.info.bulk.length > 1) {
		if (!storage.job.info.bulk.includes(utils.prettyUrl(window.location.href))) { return };
		if (storage.job.bulk && Object.keys(storage.job.bulk).includes(utils.prettyUrl(window.location.href))) { return };
		bulk = true;
	} else {
		return;
	};
	console.log("doing itt");

	let name, weight, price, image

	if (store === "ASDA") {
		name = document.getElementsByClassName(ELEMENTS[store].prodName)[0].innerText;
		weight = document.getElementsByClassName(ELEMENTS[store].prodWeight)[0].innerText;
		price = document.getElementsByClassName(ELEMENTS[store].prodPrice)[0].childNodes[1].data;
		image = document.getElementsByClassName(ELEMENTS[store].prodImage)[0].children[0].srcset;
	} else if (store === "MORRISONS") {
		name = document.getElementsByClassName(ELEMENTS[store].prodName)[0].firstChild.firstChild.textContent;
		weight = document.getElementsByClassName(ELEMENTS[store].prodWeight)[0].innerText;
		price = document.getElementsByClassName(ELEMENTS[store].prodPrice)[0].lastChild.data;
		image = document.getElementsByClassName(ELEMENTS[store].prodImage)[0].src;
	};

	const info = {
		"name":name,
		"weight":weight,
		"price":price,
		"imageUrl":utils.biggerImg(image),
		"url":utils.prettyUrl(window.location.href),
		"store":"ASDA"
	};

	if (bulk === false) {
		storage.job["asda"] = [info];
	} else {
		if (!storage.job.bulk) { storage.job["bulk"] = {} };

		storage.job.bulk[info.url] = info;
	};

	await browser.storage.local.set(storage);

	await utils.cacheSet(info.url, info);

	window.close();
}

async function init() {
	utils = await import(browser.runtime.getURL("../utils.js"));
	console.log(utils.ASDA_SEARCH);
};

init().then(() => {
	let store = utils.storeFromUrl(window.location.href);

	if (window.location.href.startsWith(utils[store+"_SEARCH"])) {
		console.log("he;lllooO!!");
		fromSearch(store);
	} else {
		if (store === "MORRISONS" && window.location.href.includes("browse")) {
			fromSearch(store);
		} else {
			fromProduct(store);
		};
	};
});

console.log(window.location.href);