//import { waitForElement, waitFor, waitForEntries, delay, ASDA_SEARCH, RESULTS_TO_LOAD, ASDA } from "../utils.js";

//let waitForElement, waitFor, waitForEntries, delay, ASDA_SEARCH, RESULTS_TO_LOAD, ASDA

let utils;

async function getFromListItem(i) {
	let nameElem = i.getElementsByClassName("co-product__anchor")[0];
	let weight = i.getElementsByClassName("co-product__volume co-item__volume")[0].innerText;
	let price = i.getElementsByClassName("co-product__price")[0].childNodes[1].data;
	let image = i.getElementsByClassName("asda-img asda-image thumbnail__image")[0].currentSrc;

	console.log(nameElem, weight, price, image);

	const info = {
		"name":nameElem.innerText,
		"weight":weight,
		"price":price,
		"imageUrl":utils.biggerImg(image),
		"url":nameElem.href,
		"store":"ASDA"
	};

	await utils.cacheSet(utils.prettyUrl(info.url), info);

	return new Promise(resolve => {resolve(info)});
};

async function checkedBox(item) {
	const storage = await browser.storage.local.get();
	
	storage.job["chosen_asda"] = await getFromListItem(item);

	await browser.storage.local.set(storage);
	
	window.close();
};

async function manualSearch(storage) {
	const topMenu = document.getElementsByClassName("top-menu")[0];

	const a = document.createElement("a");
	a.innerHTML = "Matching: " + storage.job.info.search.replaceAll("%20"," ");
	a.style = "font-weight: bolder;";

	topMenu.insertAdjacentElement("afterbegin", a);

	let allResults = document.getElementsByClassName(" co-item co-item--rest-in-shelf ");
	allResults = Array.from(allResults);

	console.log(storage.job);

	const storageWeight = storage.job.info.weight;

	for (let i of allResults) {
		let thisWeight = i.getElementsByClassName("co-product__volume co-item__volume")[0].innerText;

		console.log(storageWeight, thisWeight, utils.matchWeights(storageWeight, thisWeight));

		if (utils.matchWeights(storageWeight, thisWeight)) {
			i.style.background = "#efffd6";
		};

		const c = document.createElement("input");
		c.type = "checkbox";
		c.style = "float: right; height: 20px; width: 20px;";
		c.addEventListener("click", function() { checkedBox(i) });

		i.children[0].children[0].insertAdjacentElement("afterbegin", c);
	};
};

async function scrapingSearch(storage) {
	let allResults = document.getElementsByClassName(" co-item co-item--rest-in-shelf ");
	allResults = Array.from(allResults);

	let sliced = allResults.slice(0, Math.min(allResults.length, utils.RESULTS_TO_LOAD));
	let usefulResults = [];

	for (let i of sliced) {
		console.log("waiting");
		await utils.waitFor(i,"asda-img asda-image thumbnail__image")

		console.log("waited");

		usefulResults.push(await getFromListItem(i));
	};

	storage.job["asda"] = usefulResults;

	await browser.storage.local.set(storage);
	console.log(JSON.stringify(usefulResults));
	console.log(usefulResults);
	window.close();
}

async function fromSearch() {
	await utils.waitForElement(".search-page-content__products-tab-content");
	await utils.waitForEntries();

	const storage = await browser.storage.local.get();
	
	if (!storage.job) {return};
	if (!storage.job.missing_asda && storage.job.asda) {return};
	if (window.location.href !== utils.ASDA_SEARCH + storage.job.info.search) {return};

	if (storage.job.missing_asda) {manualSearch(storage)} else {scrapingSearch(storage)};
};


async function fromProduct() {
	console.log("waiting 1");
	await utils.waitForElement(".pdp-main-details__title");
	console.log("waiting 2");
	//await utils.waitFor(document,"asda-img asda-image asda-image-zoom__zoomed-image");
	await utils.waitFor(document,"asda-image-zoom__zoomed-image-container asda-image-zoom__zoomed-image-container--hide");
	console.log("waiting 3");
	await utils.waitForContent(document, "pdp-main-details__title");

	console.log("waited all");
	const storage = await browser.storage.local.get();

	let bulk = false;

	if (!storage.job) {return};
	if (storage.job.asda) {return};
	if (storage.job.info.bulk.length === 1 && storage.job.info.matches) {
		if (!storage.job.info.matches.others.includes(utils.prettyUrl(window.location.href))) {return};
	} else if (storage.job.info.bulk.length > 1) {
		if (!storage.job.info.bulk.includes(utils.prettyUrl(window.location.href))) { return };
		bulk = true;
	} else {
		return;
	};
	console.log("doing itt");

	let nameElem = document.getElementsByClassName("pdp-main-details__title")[0];
	let weight = document.getElementsByClassName("pdp-main-details__weight")[0].innerText;
	let price = document.getElementsByClassName("co-product__price pdp-main-details__price")[0].childNodes[1].data;
	let image = document.getElementsByClassName("asda-image picture")[0].children[0].srcset;

	const info = {
		"name":nameElem.innerText,
		"weight":weight,
		"price":price,
		"imageUrl":utils.biggerImg(image),
		"url":utils.prettyUrl(window.location.href),
		"store":"ASDA"
	};

	if (bulk === false) {
		storage.job["asda"] = [info];
	} else {
		if (!storage.job.bulk) { storage.job["bulk"] = {} };

		storage.job.bulk[info.url] = info;
	};

	await browser.storage.local.set(storage);

	await utils.cacheSet(info.url, info);

	window.close();
}

async function init() {
	utils = await import(browser.runtime.getURL("../utils.js"));
	console.log(utils.ASDA_SEARCH);
};

init().then(() => {
	if (window.location.href.startsWith(utils.ASDA_SEARCH)) {
		console.log("he;lllooO!!");
		fromSearch();
	} else {
		fromProduct();
	};
});

console.log(window.location.href);