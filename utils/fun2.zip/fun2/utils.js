export function waitFor(elem, name, func, content=false) {
	function get() {
		let children;

		if (func === "class") {
			children = elem.getElementsByClassName(name);
		} else if (func === "tag") {
			children = elem.getElementsByTagName(name);
		};

		if (children.length > 0) {
			if (content === true) { if (children[0].innerText !== "") { return children; };} 
			else { return children; };
		};
	};

	return new Promise((resolve) => {
		let children = get();

		if (children) { resolve(children) };

		const observer = new MutationObserver(function(changes) {
			let children = get();

			if (children) { resolve(children) };
		});

		observer.observe(elem, { childList: true, subtree: true });
	});
};

export function waitUntilNone(elem, childClass) {
	return new Promise((resolve) => {
		let children = elem.getElementsByClassName(childClass);
		console.log(children)

		if (children.length === 0) { resolve(children); };

		const observer = new MutationObserver(function(changes) {
			children = elem.getElementsByClassName(childClass);
			console.log(children);
			if (children.length === 0) { resolve(children); };
		})

		observer.observe(elem, { childList: true, subtree: true });
	});
};