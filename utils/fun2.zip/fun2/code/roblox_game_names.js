const patterns = [
	/\[.*?\]/g, //square brackets
	/\(.*?\)/g, //normal brackets
	"!",
	/[\u{1F600}-\u{1F64F}\u{1F300}-\u{1F5FF}\u{1F680}-\u{1F6FF}\u{1F700}-\u{1F77F}\u{1F780}-\u{1F7FF}\u{1F800}-\u{1F8FF}\u{1F900}-\u{1F9FF}\u{1FA00}-\u{1FA6F}\u{1FA70}-\u{1FAFF}\u{2600}-\u{26FF}\u{2700}-\u{27BF}\u{2B50}]/gu, //emojis
	/^\s+/g, //space at start
	/\uFE0F/g //weird variation selector 16 sometimes appears as a space on roblox
];

const gameTitleElems = [
	"game-name-title",
	"game-name",
	"slide-item-name",
	"game-card-name",
	"place-name"
];

const polyPoints = [
	[0,0],
	[73,0],
	[80,20],
	[0,20]
]

const GAME_INFO_API = "https://games.roblox.com/v1/games?universeIds=";
const GAME_VOTES_API = "https://games.roblox.com/v1/games/votes?universeIds=";

let utils;
let toClone;

function getNiceName(str) {
	const original = String(str);

	for (let r of patterns) {
		str = str.replace(r,"");
	};

	if (str === "") { return original };

	return str
};

function formatBigNumber(num) {
	if (num < 1_000) {
		return String(num);
	} else if (num < 1_000_000) {
		const rounded = Math.round(num / 100) / 10;
		return String(rounded) + "K";
	} else {
		const rounded = Math.round(num / 10_000) / 10;
		return String(rounded) + "M";
	};
};

function editCards(response) {
	const results = {};

	for (let [url,data] of Object.entries(response.response)) {
		console.log(url,JSON.stringify(data));

		for (let entry of data.data) {
			if (!results[entry.id]) { results[entry.id] = {}; };

			if (url.includes(GAME_INFO_API)) {
				results[entry.id].info = entry;
			} else if (url.includes(GAME_VOTES_API)) {
				results[entry.id].votes = entry;
			};
		};
	};

	for (let [uniId, data] of Object.entries(results)) {
		let elem = document.getElementById(uniId);

		console.log(elem.tagName)

		const playing = data.info.playing;
		const upVotes = Number(data.votes.upVotes);
		const downVotes = Number(data.votes.downVotes);
		const votes = Math.round((upVotes / (upVotes + downVotes))*100);

		const c = toClone.cloneNode(true);
		c.getElementsByClassName("vote-percentage-label")[0].innerText = votes + "%";
		c.getElementsByClassName("playing-counts-label")[0].innerText = formatBigNumber(playing);

		if (elem.tagName === "A") { //small game card
			let cardInfo = elem.getElementsByClassName("game-card-info")[0];
			cardInfo.style.position = "absolute";

			let infoLabel = cardInfo.getElementsByClassName("info-label")[0];

			if (infoLabel) { //not active friends
				cardInfo.style.bottom = "-7px";
				cardInfo.style.left = "-3px";
		
				infoLabel.style.position = "absolute";
				infoLabel.style.left = "10px";
				infoLabel.style.top = "0px";
		
				const svg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
				svg.setAttribute("height", "20");
				svg.setAttribute("width","80");
		
				const poly = document.createElementNS("http://www.w3.org/2000/svg", "polygon");
				poly.setAttribute("fill", "#232527");
				poly.style.stroke = "#3e4246";
				poly.style.position = "relative";
				svg.append(poly);
				
				for (let v of polyPoints) {
					let p = svg.createSVGPoint();
					p.x = v[0];
					p.y = v[1];
					poly.points.appendItem(p);
				};
				
				cardInfo.append(svg);
			};

			elem.getElementsByTagName("span")[0].append(cardInfo);
			elem.append(c);
		} else if (elem.tagName === "LI") { //big game image
			elem = elem.firstChild.firstChild; //"a"

			let cardInfo = elem.getElementsByClassName("game-card-info")[0];
			cardInfo.style.position = "absolute";

			if (cardInfo.getElementsByClassName("icon-pastname").length > 0) {
				cardInfo.getElementsByClassName("icon-pastname")[0].remove();
				cardInfo.style.bottom = "-6px";

				let infoLabel = cardInfo.getElementsByClassName("text-label-with-icon")[0];
				infoLabel.innerText = infoLabel.innerText.replace(" visited", "");

				infoLabel.style.position = "absolute";
				infoLabel.style.left = "10px";
				infoLabel.style.top = "0px";
		
				const svg = document.createElementNS("http://www.w3.org/2000/svg", "svg");;
				svg.setAttribute("height", "20");
				svg.setAttribute("width","80");
		
				const poly = document.createElementNS("http://www.w3.org/2000/svg", "polygon");
				poly.setAttribute("fill", "#232527");
				poly.style.stroke = "#3e4246";
				poly.style.position = "relative";
				svg.append(poly);
				
				for (let v of polyPoints) {
					let p = svg.createSVGPoint();
					p.x = v[0];
					p.y = v[1];
					poly.points.appendItem(p);
				};
				
				cardInfo.append(svg);
				elem.getElementsByTagName("span")[0].append(cardInfo);

			} else {
				cardInfo.remove();
			};

			elem.append(c);
		};
	};
};

async function main() {
	const storage = await browser.storage.local.get();

	if (storage.roblox_game_names !== true) {
		throw Error("Feature not selected.");
	};


	//replace document title with clean one
	if (window.location.href.includes("/games/")) { document.title = getNiceName(document.title); };

	//make homepage show me again :)
	await utils.waitFor(document, "thumbnail-2d-container", "class");

	if (window.location.href.includes("/home")) {
		const upsell = document.getElementById("home-page-upsell-card-container");

		if (upsell.getElementsByTagName("img").length === 0) {
			document.getElementsByClassName("section")[0].remove();

			upsell.style.marginBottom = "20px";
			upsell.style.marginTop = "10px";
	
			const nav = document.getElementById("navigation");
			const span = nav.getElementsByClassName("thumbnail-2d-container avatar-card-image")[0];

			await utils.waitFor(span, "img", "tag"); //img class is ""

			const img = span.getElementsByTagName("img")[0].cloneNode(true);

			img.style.width = "100px";
			img.style.borderRadius = "50%";
			img.style.borderColor = "#3e4246";
			img.style.borderWidth = "1px";
			img.style.borderStyle = "solid";
			
			const h1 = document.createElement("h1");
			h1.style.display = "inline";
			h1.style.marginLeft = "20px";
			h1.innerText = "Hi, " + img.title;

			
			upsell.append(img, h1);
		};
	};

	//wait for game cards
	await utils.waitFor(document, "game-name-title", "class")
	await utils.waitUntilNone(document, "shimmer", "class", true);

	//replace names with clean ones
	const elements = [];
	
	for (let e of gameTitleElems) {
		elements.push(...Array.from(document.getElementsByClassName(e)));
	};
	
	for (let e of elements) { e.innerText = getNiceName(e.innerText); };

	//wait for new game cards
	const gamesPageCont = document.getElementsByClassName("games-page-container")[0];
	if (gamesPageCont) {
		new MutationObserver(function(changes) {	
			setTimeout(function() {
				for (let c of changes) {
					for (let e of c.addedNodes) {
						if (e.className !== "games-list-container") { continue; };

						for (let n of e.getElementsByClassName("game-card-name")) { n.innerText = getNiceName(n.innerText); };						
					};
				};
			}, 1);
		}).observe(gamesPageCont, { childList: true })
	}

	//remove friends thing that hides player count (nicer game cards)
	for (let e of document.getElementsByClassName("game-card-info")) {
		if (e.getElementsByClassName("playing-counts-label").length > 0) {
			toClone = e;
			break;
		};
	};

	/*for (let e of document.getElementsByClassName("game-card-info")) {
		if (e.getElementsByClassName("playing-counts-label").length === 0) {
			let uniId;

			if (e.parentElement.className === "base-metadata") { //is big picture not card
				uniId = e.parentElement.parentElement.parentElement.parentElement.parentElement.parentElement.id;
			} else {
				uniId = e.parentElement.id;
			};

			console.log(e);

			if (!uniId) { continue; };

			const gameInfo = GAME_INFO_API + uniId;
			const gameVotes = GAME_VOTES_API + uniId;
			
			const response = await browser.runtime.sendMessage({
				"module":"roblox",
				"function": "fetch-apis",
				"urls":[gameInfo, gameVotes]
			});

			const infoResult = response.response[gameInfo];
			const votesResult = response.response[gameVotes];

			console.log(infoResult);
			console.log(JSON.stringify(response));
			const playing = Number(infoResult.data[0].playing);

			const upVotes = Number(votesResult.data[0].upVotes);
			const downVotes = Number(votesResult.data[0].downVotes);
			const votes = Math.round((upVotes / (upVotes + downVotes))*100);

			const c = toClone.cloneNode(true);
			c.getElementsByClassName("vote-percentage-label")[0].innerText = votes + "%";
			c.getElementsByClassName("playing-counts-label")[0].innerText = formatBigNumber(playing);

			e.style.position = "absolute";
			
			let infoLabel;

			if (e.parentElement.className === "base-metadata") { //is big picture not card
				if (e.getElementsByClassName("icon-votes-gray").length > 0) {
					e.remove();
					infoLabel = {};

				} else {
					e.getElementsByClassName("icon-pastname")[0].remove();
					let text = e.getElementsByClassName("text-label-with-icon")[0];

					text.innerText = text.replace(" visited", "");
				};
			} else {
				infoLabel = e.getElementsByClassName("info-label");
			};

			//style overlay of friend indicator on thumbnail
			if (infoLabel.length > 0) {
				e.style.bottom = "-7px";
				e.style.left = "-3px";

				infoLabel[0].style.position = "absolute";
				infoLabel[0].style.left = "10px";
				infoLabel[0].style.top = "0px";

				const svg = document.createElementNS("http://www.w3.org/2000/svg", "svg");;
				svg.setAttribute("height", "20");
				svg.setAttribute("width","80");

				const poly = document.createElementNS("http://www.w3.org/2000/svg", "polygon");
				poly.setAttribute("fill", "#232527");
				poly.style.stroke = "#3e4246";
				poly.style.position = "relative";
				svg.append(poly);
				
				for (let v of polyPoints) {
					let p = svg.createSVGPoint();
					p.x = v[0];
					p.y = v[1];
					poly.points.appendItem(p);
				};
				
				e.append(svg);
			};

			if (e.parentElement.className === "base-metadata") { //is big picture not card
				e.parentElement.append(c);
				e.parentElement.parentElement.parentElement.parentElement.getElementsByClassName("thumbnail-2d-container")[0].append(e);
			} else {
				e.parentElement.getElementsByClassName("game-card-thumb-container")[0].append(e);
				e.parentElement.parentElement.append(c);
			};
		};
	};*/

	//make nicer game cards
	const uniIds = [];

	for (let e of document.getElementsByClassName("game-card-info")) {
		if (e.getElementsByClassName("playing-counts-label").length === 0) {
			let uniId;

			if (e.parentElement.className === "base-metadata") { //is big picture not card
				uniId = e.parentElement.parentElement.parentElement.parentElement.parentElement.parentElement.id;
			} else {
				uniId = e.parentElement.id;
			};

			console.log(e);

			if (!uniId) { continue; };

			uniIds.push(uniId);
		};
	};

	const urls = [];
	let sliceStart = 0;
	let amtPerReq = 99;

	for (let i of Array.from(Array(Math.floor(uniIds.length/amtPerReq)).keys())) {
		i += 1;
		console.log(i,"i");
		console.log(sliceStart,"sliceStart");

		let ids = uniIds.slice(sliceStart, i*amtPerReq).join();
		urls.push([GAME_INFO_API + ids, GAME_VOTES_API + ids]);
		sliceStart = i*amtPerReq;
	};

	if (uniIds.length % amtPerReq !== 0) {
		console.log(uniIds.length % amtPerReq);

		let ids = uniIds.slice(sliceStart, sliceStart + uniIds.length % amtPerReq).join();
		urls.push([GAME_INFO_API + ids, GAME_VOTES_API + ids]);
	};

	console.log(uniIds.length,"total uniIds");
	console.log(urls.length,"urls length")
	console.log(JSON.stringify(urls));

	for (let grp of urls) {
		browser.runtime.sendMessage({
			"module":"roblox",
			"function": "fetch-apis",
			"urls":grp
		}).then(editCards);
	};

	// set nice name on game card on friend hover
	new MutationObserver(function(changes) {
		setTimeout(function() {
			const elem = document.getElementsByClassName("place-title")[0];

			if (elem && elem.innerText !== "") {
				console.log(elem,"ELEM", elem.innerText);
				elem.innerText = getNiceName(elem.innerText);
			};
		}, 1);
	}).observe(document.body, { childList: true });
};

async function init() {
	utils = await import(browser.runtime.getURL("../utils.js"));
};

init().then(main())