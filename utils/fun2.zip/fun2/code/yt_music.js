let utils;

folders = {
	"fun": ["PLhYV96hJwkJaTCwitpCy-vRF8zUZYwMfb","PLhYV96hJwkJZwh8UdI0ndRnTWLiPz5xjL","PLhYV96hJwkJY_mggSWatbrVgnsEY5Lv0L","PLhYV96hJwkJYKEag35jbI8T3KfGub1iwS","PLhYV96hJwkJZNsigJv_Pl4rzS4P2rHzKV","PLhYV96hJwkJbSEFJbYD7NillsNKp2GNCh","PLhYV96hJwkJb1dmBbokA-OGoEco38EPM3"],
	"yes": ["PLhYV96hJwkJY4HHD_EyhfC2n7j7zhaigc","PLhYV96hJwkJZZJ_9Zgs3c8fyp7UX3JCCF","PLhYV96hJwkJbfkB6v2JtBwt-EXqt4bNui","PLhYV96hJwkJYCrgMgG9eActFJ7JqEAKEK","PLhYV96hJwkJZygTDFoTFz-D_VfvLWM0Of","PLhYV96hJwkJbtsrIO3SCDUbQ2bASXrVEW","PLhYV96hJwkJbx1D2J4jEXoN8unJJYizEJ"],
	"mhm": ["PLLuS5oZTvqvxvhJMx7h-RXqUbTw_IJQya","PLhYV96hJwkJaPxPLZO7urZtpugL7RI53i","PLhYV96hJwkJaxiOrGLA89Y91agiAP-VVa","PLhYV96hJwkJaixJGt6R1RvI1v-o31XhB5","PLhYV96hJwkJa2NRUWYQfYm5eaHgkIOopu","PLhYV96hJwkJbN1hUbecsyB4mjdcF0D5Pf","PLhYV96hJwkJaN_y2GOKY-HjbNx8_nqmWl"],
	"wow": ["PLhYV96hJwkJZM63mocc3dWIh40U29bu12","PLhYV96hJwkJYcy1RycdLdW9_FjJhBQYxt","PLhYV96hJwkJYTAdFO3jeCmID5KL3S1uqh","PLhYV96hJwkJZnTfzepPqMa4Dy6K8B-mL3","PLhYV96hJwkJZXDOAf2NAuCd1NRo-wk0Dv","PLhYV96hJwkJY1oVOgDZHx0kcYg1Nx0dWO","PLhYV96hJwkJb4PB_MHALkbkda6F3iCNvO"],
	"woo": ["PLhYV96hJwkJaCJYhsFfaOzZirnrvjnP2v","PLhYV96hJwkJbe7Ch12s-CKBWIj2DA4UPD","PLhYV96hJwkJYKGvfQsXhBHbePaClNMzIl","PLhYV96hJwkJYZ_qIvcOU-0l3dzSmZhBBP","PLhYV96hJwkJaFgmsgNKD2osZLa2M_ugc5","PLlJddkadYDcBwrdvOw_Q9fGCxPX5_2w85","PLhYV96hJwkJbtroQgtOMQ4yVwPUPXwQNl"],
	"ohh": ["PLhYV96hJwkJYa-PnJYO4w5NicytIxCTC5","PLhYV96hJwkJbwWYkfZ1PmS5Eg555EbJH7","PLhYV96hJwkJZNmEzMpTr4yoEU3wZBoVVP","PLWBWOYxdVaIimZ-xdItJxsInquC7ugM8h","PLhYV96hJwkJbC-Rfc1Fc6nvdl4nJJOlIr","PLfOP-w0nfUr9brhmhidSa61ySsbLiXzPV","PL5A4nPQbUF8D93md-24ZAAhN3t5q-S0rS"],
	"luv": ["PLLUqkV4E3Gb4reuTU3LicBjxwOH7qLYkE","SE", "LM"]
};

function createSubList(pInfo) {

};

async function main() {
	if (window.location.href !== "https://music.youtube.com/playlist?list=OLAK5uy_lrJakDq8vTWmFU327tp_oI1zgSishISOY") {return;};
	
	const storage = await browser.storage.local.get();

	const itemsPanel = document.getElementById("sections").children[1].children[2];
	const templateCard = itemsPanel.children[0].cloneNode(true);
	console.log(itemsPanel);
	console.log(templateCard);

	const paper = templateCard.getElementsByTagName("TP-YT-PAPER-ITEM")[0];

	templateCard.style.maxHeight = "";
	console.log(templateCard.children);
	
	templateCard.getElementsByTagName("ytmusic-play-button-renderer")[0].remove();
	templateCard.getElementsByTagName("span")[0].remove();

	const folderPanels = {}
	
	for (let i of Object.keys(folders)) {
		const panel = itemsPanel.cloneNode(true);
		
		for (let c of panel.children) {
			c.remove();
		};

		folderPanels[i] = panel;
	};

	for (let i of itemsPanel.children) {
		const id = i.getElementsByTagName("tp-yt-paper-item")[0]//.__dataHost.__data.data.entryData.guideEntryData.guideEntryId;
		console.log(id.);
		let name;

		for (let [f,v] in Object.entries(folders)) {
			if (v.includes(id)) {
				name = f;
				break;
			};
		};

		if (name) {
			folderPanels[name].append(i);
		};
	};

	templateCard.append(folderPanels["fun"]);
	itemsPanel.append(templateCard);
};

async function init() {
	utils = await import(browser.runtime.getURL("../utils.js"));

	// for (let v of .getElementsByTagName("tp-yt-paper-item")) { console.log(v.__dataHost.__data.data.entryData.guideEntryData.guideEntryId) } 
};

init().then(main())