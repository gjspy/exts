//mw-collapsible-content

let utils;

async function main() {
	const storage = await browser.storage.local.get();

	if (storage.roblox_game_names !== true) {
		throw Error("Feature not selected.");
	};

	//await utils.waitFor(document, "mw-collapsible-content");

	for (let d of document.getElementsByClassName("mw-collapsible-content")) {
		d.style.display = "";
	};
};

async function init() {
	utils = await import(browser.runtime.getURL("../utils.js"));
};

init().then(main())