async function roblox(request, sender) {
	console.log("in roblox");
	if (request.function === "fetch-apis") {
		const results = {};

		for (let api of request.urls) {
			const r = await fetch(api, { method: "GET" });
			results[api] = await r.json();
		};

		console.log(JSON.stringify(results));
		return { response: results };
	};
};

browser.runtime.onMessage.addListener(function(request, sender) {
	console.log("in listener", JSON.stringify(request), sender);

	let func;

	if (request.module === "roblox") { func = roblox; }
	else if (request.module) {}//...

	console.log(func)
	let result = func(request, sender);

	return new Promise((resolve) => {
		resolve(result);
	});
	
});