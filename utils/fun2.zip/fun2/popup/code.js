const funcs = [
	"roblox_game_names",
	"wiki_expandables",
	"yt_music"
];

async function onClick(box, f) {
	const storage = await browser.storage.local.get();
	storage[f] = box.checked;
	await browser.storage.local.set(storage);
}

async function main() {
	const li = document.getElementsByClassName("list-item")[0];
	console.log(document.getElementsByClassName("list-item")[0].children)

	for (let f of funcs) {
		const c = li.cloneNode(true);
		c.getElementsByTagName("label")[0].innerText = f;

		const box = c.getElementsByTagName("input")[0];
		box.addEventListener("click", function() { onClick(box, f) });

		const storage = await browser.storage.local.get();
		box.checked = storage[f] === true;

		c.hidden = false;
		document.getElementById("ul").append(c);
	};
};

main();